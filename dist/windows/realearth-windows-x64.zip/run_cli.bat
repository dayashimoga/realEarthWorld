@echo off
"%~dp0realearth-cli.exe" %*
