﻿# Real Earth Geographic Region Package: San Francisco Bay Area (Pilot)
- **Region ID:** san-francisco
- **Format:** SQLite Catalog (chunks.db) + Zstd Binary Chunks (.rec)
- **NAVD88 Elevation:** 0.0m - 105.0m MSL
- **Chunks:** 30 authentic surveyed tiles

## Installation
Extract the 'world_san_francisco' directory into your Real Earth 'data/' folder:
  <realearth_install_dir>/data/world_san_francisco/

Then launch the viewer:
  realearth-viewer --region san-francisco
